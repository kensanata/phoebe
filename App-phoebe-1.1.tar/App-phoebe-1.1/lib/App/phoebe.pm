package App::phoebe;

our $VERSION = 1.1.1;

=head1 NAME

App::phoebe - an app that serves a wiki as a Gemini and web site

=head1 DESCRIPTION

This is a stub module, see F<script/phoebe> for details of the app.

=head1 AUTHOR

Alex Schroeder

=head1 LICENSE

GNU Affero General Public License

=cut

1;
